"""Small file-backed profile store used only by the demo."""

import json
import os
import tempfile
from pathlib import Path

PROFILE_PATH = Path(__file__).resolve().parent.parent / "data" / "profile.json"


def read_profile() -> dict:
    return json.loads(PROFILE_PATH.read_text(encoding="utf-8"))


def save_preferred_name(preferred_name: str) -> dict:
    """Replace the profile file atomically so an interrupted write is not corrupt."""
    serialized = json.dumps({"preferredName": preferred_name}, indent=2) + "\n"
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", dir=PROFILE_PATH.parent, delete=False
    ) as temporary:
        temporary.write(serialized)
        temporary_path = temporary.name
    os.replace(temporary_path, PROFILE_PATH)
    return {"preferredName": preferred_name}


def validate_preferred_name(value: object) -> str:
    if not isinstance(value, str):
        raise ValueError("preferredName must be a string.")
    preferred_name = value.strip()
    if not 1 <= len(preferred_name) <= 80:
        raise ValueError("preferredName must contain 1 to 80 characters.")
    return preferred_name
