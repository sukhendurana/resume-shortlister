"""Minimal dependency-free MCP JSON-RPC server over standard input/output."""

import json
import sys

from mcp_core import RESOURCES, TOOLS, call_tool, read_resource


def send(payload: dict) -> None:
    sys.stdout.write(json.dumps(payload) + "\n")
    sys.stdout.flush()


def respond(request_id: object, result: dict) -> None:
    send({"jsonrpc": "2.0", "id": request_id, "result": result})


def fail(request_id: object, error: Exception) -> None:
    send(
        {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {"code": -32000, "message": str(error)},
        }
    )


def handle(request: dict) -> None:
    request_id = request.get("id")
    method = request.get("method")
    params = request.get("params") or {}
    if method == "notifications/initialized":
        return

    try:
        if method == "initialize":
            respond(
                request_id,
                {
                    "protocolVersion": params.get("protocolVersion", "2025-03-26"),
                    "capabilities": {"tools": {}, "resources": {}},
                    "serverInfo": {"name": "preferred-name-a2ui-demo", "version": "1.0.0"},
                },
            )
        elif method == "tools/list":
            respond(request_id, {"tools": TOOLS})
        elif method == "resources/list":
            respond(request_id, {"resources": RESOURCES})
        elif method == "resources/read":
            respond(request_id, read_resource(params.get("uri")))
        elif method == "tools/call":
            respond(request_id, call_tool(params.get("name"), params.get("arguments")))
        else:
            raise ValueError(f"Method not supported: {method}")
    except Exception as error:  # JSON-RPC transports errors as data.
        fail(request_id, error)


for line in sys.stdin:
    if not line.strip():
        continue
    try:
        handle(json.loads(line))
    except json.JSONDecodeError as error:
        fail(None, error)
