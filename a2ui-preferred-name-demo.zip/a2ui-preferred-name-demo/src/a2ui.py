"""A2UI envelopes and resource helpers for the preferred-name surface."""

import json

A2UI_VERSION = "v0.9.1"
A2UI_MIME_TYPE = "application/a2ui+json"
CATALOG_ID = "demo://squiggly/profile-components/v1"
PREFERRED_NAME_RESOURCE_URI = "a2ui://preferred-name-confirmation"
PREFERRED_NAME_SURFACE_ID = "preferred-name-confirmation"


PREFERRED_NAME_TEMPLATE = [
    {
        "version": A2UI_VERSION,
        "createSurface": {
            "surfaceId": PREFERRED_NAME_SURFACE_ID,
            "catalogId": CATALOG_ID,
            # The host sends surface state on an action. The server still
            # validates every action and never trusts that state as authority.
            "sendDataModel": True,
        },
    },
    {
        "version": A2UI_VERSION,
        "updateComponents": {
            "surfaceId": PREFERRED_NAME_SURFACE_ID,
            "components": [
                {
                    "id": "root",
                    "component": "Column",
                    "children": [
                        "heading",
                        "explanation",
                        "comparison",
                        "status",
                        "confirm-button",
                    ],
                },
                {
                    "id": "heading",
                    "component": "Text",
                    "variant": "h2",
                    "text": "Confirm your preferred-name change",
                },
                {
                    "id": "explanation",
                    "component": "Text",
                    "text": "Review the proposed change before saving it.",
                },
                {
                    "id": "comparison",
                    "component": "ComparisonTable",
                    "oldValue": {"path": "/oldName"},
                    "newValue": {"path": "/newName"},
                },
                {
                    "id": "status",
                    "component": "Text",
                    "variant": "status",
                    "text": {"path": "/statusText"},
                },
                {
                    "id": "confirm-button",
                    "component": "Button",
                    "label": "Confirm change",
                    "variant": "primary",
                    "disabled": {"path": "/confirmed"},
                    "action": {
                        "event": {
                            "name": "confirm_preferred_name",
                            "context": {
                                "oldName": {"path": "/oldName"},
                                "newName": {"path": "/newName"},
                            },
                        }
                    },
                },
            ],
        },
    },
]


def data_model_update(value: dict) -> list[dict]:
    return [
        {
            "version": A2UI_VERSION,
            "updateDataModel": {
                "surfaceId": PREFERRED_NAME_SURFACE_ID,
                "path": "/",
                "value": value,
            },
        }
    ]


def a2ui_embedded_resource(messages: list[dict], uri: str | None = None) -> dict:
    return {
        "type": "resource",
        "resource": {
            "uri": uri or f"{PREFERRED_NAME_RESOURCE_URI}/data",
            "mimeType": A2UI_MIME_TYPE,
            "text": json.dumps(messages),
        },
    }
