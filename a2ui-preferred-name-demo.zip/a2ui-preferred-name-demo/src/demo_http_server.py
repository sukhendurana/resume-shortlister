"""Local-only HTTP adapter for the browser demo. The production transport is MCP stdio."""

import json
import os
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from mcp_core import call_tool, read_resource

ROOT = Path(__file__).resolve().parent.parent / "public"
HOST = "127.0.0.1"
PORT = int(os.environ.get("PORT", "3000"))
STATIC_FILES = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/app.js": ("app.js", "application/javascript; charset=utf-8"),
    "/styles.css": ("styles.css", "text/css; charset=utf-8"),
}


class DemoHandler(BaseHTTPRequestHandler):
    def send_json(self, status: HTTPStatus, body: dict) -> None:
        encoded = json.dumps(body).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)

    def read_json(self) -> dict:
        size = int(self.headers.get("Content-Length", "0"))
        return json.loads(self.rfile.read(size) or b"{}")

    def do_GET(self) -> None:  # noqa: N802 - required stdlib handler name.
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/mcp/resources":
                uri = parse_qs(parsed.query).get("uri", [None])[0]
                self.send_json(HTTPStatus.OK, read_resource(uri))
                return
            if parsed.path in STATIC_FILES:
                filename, content_type = STATIC_FILES[parsed.path]
                content = (ROOT / filename).read_bytes()
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return
            self.send_json(HTTPStatus.NOT_FOUND, {"error": "Not found"})
        except Exception as error:
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": str(error)})

    def do_POST(self) -> None:  # noqa: N802 - required stdlib handler name.
        if urlparse(self.path).path != "/mcp/tools/call":
            self.send_json(HTTPStatus.NOT_FOUND, {"error": "Not found"})
            return
        try:
            request = self.read_json()
            self.send_json(
                HTTPStatus.OK,
                call_tool(request.get("name"), request.get("arguments")),
            )
        except Exception as error:
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": str(error)})

    def log_message(self, format: str, *args: object) -> None:
        # Keep the teaching demo's terminal output focused on its startup URL.
        return


if __name__ == "__main__":
    with ThreadingHTTPServer((HOST, PORT), DemoHandler) as server:
        print(f"A2UI demo chat: http://{HOST}:{PORT}")
        server.serve_forever()
