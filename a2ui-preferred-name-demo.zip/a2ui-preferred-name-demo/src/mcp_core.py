"""Transport-independent MCP resources and tools for the name-update flow."""

import json

from a2ui import (
    A2UI_MIME_TYPE,
    PREFERRED_NAME_RESOURCE_URI,
    PREFERRED_NAME_TEMPLATE,
    a2ui_embedded_resource,
    data_model_update,
)
from profile_store import read_profile, save_preferred_name, validate_preferred_name


def tool_ui_metadata() -> dict:
    return {
        "ui": {
            "resourceUri": PREFERRED_NAME_RESOURCE_URI,
            "mimeType": A2UI_MIME_TYPE,
        }
    }


TOOLS = [
    {
        "name": "get_preferred_name_confirmation",
        "title": "Preview preferred-name change",
        "description": "Returns an A2UI confirmation table for a proposed preferred name.",
        "inputSchema": {
            "type": "object",
            "properties": {"preferredName": {"type": "string"}},
            "required": ["preferredName"],
            "additionalProperties": False,
        },
        "_meta": tool_ui_metadata(),
    },
    {
        "name": "a2ui_action",
        "title": "Handle A2UI action",
        "description": "Receives actions emitted by the preferred-name confirmation surface.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "surfaceId": {"type": "string"},
                "sourceComponentId": {"type": "string"},
                "timestamp": {"type": "string"},
                "context": {"type": "object"},
            },
            "required": ["name", "surfaceId", "sourceComponentId", "timestamp", "context"],
            "additionalProperties": False,
        },
    },
]

RESOURCES = [
    {
        "uri": PREFERRED_NAME_RESOURCE_URI,
        "name": "Preferred-name confirmation",
        "description": "Static A2UI layout for a preferred-name confirmation card.",
        "mimeType": A2UI_MIME_TYPE,
    }
]


def read_resource(uri: str) -> dict:
    if uri != PREFERRED_NAME_RESOURCE_URI:
        raise ValueError(f"Unknown resource: {uri}")
    return {
        "contents": [
            {
                "uri": uri,
                "mimeType": A2UI_MIME_TYPE,
                "text": json.dumps(PREFERRED_NAME_TEMPLATE),
            }
        ]
    }


def tool_result(text: str, messages: list[dict], meta: dict | None = None) -> dict:
    return {
        "content": [
            {"type": "text", "text": text},
            a2ui_embedded_resource(messages),
        ],
        "_meta": meta or tool_ui_metadata(),
    }


def call_tool(name: str, arguments: dict | None = None) -> dict:
    arguments = arguments or {}
    if name == "get_preferred_name_confirmation":
        new_name = validate_preferred_name(arguments.get("preferredName"))
        profile = read_profile()
        return tool_result(
            f"Please confirm changing your preferred name from {profile['preferredName']} to {new_name}.",
            data_model_update(
                {
                    "oldName": profile["preferredName"],
                    "newName": new_name,
                    "confirmed": False,
                    "statusText": "Pending confirmation",
                }
            ),
        )

    if name == "a2ui_action":
        if (
            arguments.get("name") != "confirm_preferred_name"
            or arguments.get("sourceComponentId") != "confirm-button"
        ):
            raise ValueError(
                "This demo only accepts the confirm_preferred_name action from confirm-button."
            )

        context = arguments.get("context")
        if not isinstance(context, dict):
            raise ValueError("A2UI action context must be an object.")
        new_name = validate_preferred_name(context.get("newName"))
        profile = read_profile()
        # Prevent a stale confirmation card from overwriting a later update.
        if profile["preferredName"] != context.get("oldName"):
            raise ValueError(
                "Your profile changed since this confirmation card was opened. Request a new preview."
            )

        save_preferred_name(new_name)
        return tool_result(
            f"Saved your preferred name as {new_name}.",
            data_model_update(
                {
                    "oldName": profile["preferredName"],
                    "newName": new_name,
                    "confirmed": True,
                    "statusText": f"Saved. Your preferred name is now {new_name}.",
                }
            ),
        )

    raise ValueError(f"Unknown tool: {name}")
