# A2UI preferred-name update demo

A runnable teaching example of a Squiggly-like chat host, a **Python MCP server**, a platform skill, and an A2UI confirmation UI.

It demonstrates this user journey:

```text
User: "I want to update my preferred name to XYZ"
  → skill selects get_preferred_name_confirmation
  → MCP tool returns A2UI data and points at an A2UI template resource
  → chat client fetches and renders the pre-registered catalog components
  → user clicks Confirm change
  → client sends a2ui_action
  → MCP server validates and writes data/profile.json
```

## Run the interactive client

Requires Python 3.10+ and Node.js only to run the convenient `npm` scripts. There are no third-party Python or Node dependencies. You may invoke the Python entrypoints directly instead.

```bash
npm start
# Equivalent: python3 src/demo_http_server.py
```

Open <http://localhost:3000>. The input starts with the requested sentence. Send it, review the two-column confirmation table, then choose **Confirm change**. The file `data/profile.json` will change from `Ada` to `XYZ`.

To begin again, change `data/profile.json` back to:

```json
{ "preferredName": "Ada" }
```

## Run it as a stdio MCP server

```bash
npm run mcp
# Equivalent: python3 src/mcp_stdio_server.py
```

The server implements `initialize`, `tools/list`, `resources/list`, `resources/read`, and `tools/call` over newline-delimited JSON-RPC. For example, send:

```json
{"jsonrpc":"2.0","id":1,"method":"tools/list"}
```

`get_preferred_name_confirmation` returns an MCP `CallToolResult` with:

- `_meta.ui.resourceUri` linking to `a2ui://preferred-name-confirmation`;
- an embedded resource with MIME type `application/a2ui+json`;
- an A2UI `updateDataModel` message containing the old and proposed values.

The static resource holds `createSurface` and `updateComponents`. This lets a host cache the UI layout, while the tool returns only dynamic data. The miniature renderer in `public/app.js` understands the four component types defined in `src/a2ui-catalog.json`: `Column`, `Text`, `ComparisonTable`, and `Button`.

## What changes in a real Squiggly integration

1. Replace `demo://squiggly/profile-components/v1` in `src/a2ui.mjs` with the catalog ID that Squiggly advertises, and use exactly its component schema.
2. Replace the browser adapter in `src/demo-http-server.mjs` with Squiggly's MCP connection. Keep `src/mcp-core.mjs`; it is transport-independent business/UI logic.
3. Register `skill/SKILL.md` using Squiggly's skill registration format if it differs from this conventional Markdown example.
4. Use a user-authenticated database and an opaque, server-side proposal ID. This short demo passes old/new values through the action context only to make the data flow visible; production code must authorize the caller and never trust browser-supplied identity or approval data.
5. Scope surface IDs to the renderer session or make them unique. This demo uses one fixed surface because it models one chat session.

## Directory guide

| Path | Purpose |
| --- | --- |
| `skill/SKILL.md` | Agent instruction layer: when to invoke the MCP tool. |
| `src/mcp_core.py` | Python MCP tools, resource exposure, validation, confirmation handling. |
| `src/a2ui.py` | Static A2UI template and dynamic data-update envelopes. |
| `src/mcp_stdio_server.py` | Minimal Python MCP JSON-RPC/stdio transport. |
| `src/demo_http_server.py` | Local Python HTTP adapter used by the demo browser client. |
| `public/app.js` | Demo Squiggly-style chat client and A2UI renderer. |
| `data/profile.json` | File-backed persistence for the preferred name. |
