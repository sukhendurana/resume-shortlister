import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from mcp_core import RESOURCES, TOOLS, call_tool, read_resource  # noqa: E402
from profile_store import read_profile, save_preferred_name  # noqa: E402


class McpCoreTest(unittest.TestCase):
    def test_advertises_a2ui_resource_and_confirmation_tool(self):
        self.assertEqual(RESOURCES[0]["mimeType"], "application/a2ui+json")
        self.assertEqual(TOOLS[0]["_meta"]["ui"]["resourceUri"], RESOURCES[0]["uri"])
        template = json.loads(read_resource(RESOURCES[0]["uri"])["contents"][0]["text"])
        self.assertTrue(any("createSurface" in message for message in template))
        self.assertTrue(any("updateComponents" in message for message in template))

    def test_confirmation_updates_file_only_after_a2ui_action(self):
        original = read_profile()
        save_preferred_name("Ada")
        try:
            preview = call_tool("get_preferred_name_confirmation", {"preferredName": "XYZ"})
            preview_messages = json.loads(preview["content"][1]["resource"]["text"])
            self.assertFalse(preview_messages[0]["updateDataModel"]["value"]["confirmed"])
            self.assertEqual(read_profile()["preferredName"], "Ada")

            confirmation = call_tool(
                "a2ui_action",
                {
                    "name": "confirm_preferred_name",
                    "surfaceId": "preferred-name-confirmation",
                    "sourceComponentId": "confirm-button",
                    "timestamp": "2026-10-09T00:00:00Z",
                    "context": {"oldName": "Ada", "newName": "XYZ"},
                },
            )
            confirmation_messages = json.loads(confirmation["content"][1]["resource"]["text"])
            self.assertTrue(confirmation_messages[0]["updateDataModel"]["value"]["confirmed"])
            self.assertEqual(read_profile()["preferredName"], "XYZ")
        finally:
            save_preferred_name(original["preferredName"])


if __name__ == "__main__":
    unittest.main()
