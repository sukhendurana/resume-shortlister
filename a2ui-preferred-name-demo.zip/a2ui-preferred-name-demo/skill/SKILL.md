---
name: preferred-name-update
description: Propose and confirm a user's preferred-name change using the preferred-name MCP tools and A2UI confirmation surface.
---

# Preferred-name update

Use this skill when a user asks to change their preferred name.

1. Extract the requested name. If it is missing or ambiguous, ask the user for the exact preferred name.
2. Call `get_preferred_name_confirmation` with `{ "preferredName": "<requested name>" }`.
3. Do not claim the name was changed when the confirmation A2UI surface appears. It is only a proposal.
4. The chat host renders the returned A2UI resource. When the user presses **Confirm change**, the host sends its `a2ui_action` tool call.
5. Report success only after the `a2ui_action` result states that it was saved.

The skill does not generate the A2UI JSON itself. The MCP server owns the A2UI resource and data updates, keeping the UI contract close to the business action.
