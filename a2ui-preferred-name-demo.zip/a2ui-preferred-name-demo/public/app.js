// This is intentionally a tiny renderer, not a production implementation.
// Squiggly would supply this part: it owns the renderer and the approved A2UI
// catalog. The agent/MCP server never sends JavaScript to render the table.
const chat = document.querySelector("#chat");
const form = document.querySelector("#chat-form");
const messageInput = document.querySelector("#message");
const surfaces = new Map();
const loadedResources = new Set();

function addMessage(text, role = "assistant") {
  const message = document.createElement("div");
  message.className = `message ${role}`;
  message.textContent = text;
  chat.append(message);
  message.scrollIntoView({ block: "nearest" });
}

async function callTool(name, args) {
  const response = await fetch("/mcp/tools/call", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ name, arguments: args })
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Tool call failed.");
  return result;
}

async function processToolResult(result) {
  const resourceUri = result._meta?.ui?.resourceUri;
  if (resourceUri && !loadedResources.has(resourceUri)) {
    const response = await fetch(`/mcp/resources?uri=${encodeURIComponent(resourceUri)}`);
    const resource = await response.json();
    if (!response.ok) throw new Error(resource.error || "Could not load A2UI template.");
    for (const item of resource.contents) processA2uiMessages(JSON.parse(item.text));
    loadedResources.add(resourceUri);
  }

  for (const item of result.content ?? []) {
    if (item.type === "resource" && item.resource?.mimeType === "application/a2ui+json") {
      processA2uiMessages(JSON.parse(item.resource.text));
    }
  }
}

function processA2uiMessages(messages) {
  for (const envelope of messages) {
    if (envelope.createSurface) {
      const { surfaceId } = envelope.createSurface;
      surfaces.set(surfaceId, { ...envelope.createSurface, components: new Map(), data: {}, element: null });
    }
    if (envelope.updateComponents) {
      const surface = surfaces.get(envelope.updateComponents.surfaceId);
      if (!surface) throw new Error("A2UI component update arrived before createSurface.");
      for (const component of envelope.updateComponents.components) surface.components.set(component.id, component);
      renderSurface(surface);
    }
    if (envelope.updateDataModel) {
      const update = envelope.updateDataModel;
      const surface = surfaces.get(update.surfaceId);
      if (!surface) throw new Error("A2UI data update arrived before createSurface.");
      if (!update.path || update.path === "/") surface.data = update.value;
      else setAtJsonPointer(surface.data, update.path, update.value);
      renderSurface(surface);
    }
  }
}

function resolve(surface, value) {
  if (value && typeof value === "object" && "path" in value) return getAtJsonPointer(surface.data, value.path);
  return value;
}

function getAtJsonPointer(value, pointer) {
  return pointer.split("/").slice(1).reduce((current, key) => current?.[key], value);
}

function setAtJsonPointer(value, pointer, replacement) {
  const keys = pointer.split("/").slice(1);
  const leaf = keys.pop();
  const parent = keys.reduce((current, key) => (current[key] ??= {}), value);
  parent[leaf] = replacement;
}

function renderSurface(surface) {
  surface.element ??= document.createElement("section");
  surface.element.className = "surface";
  surface.element.replaceChildren(renderComponent(surface, "root"));
  if (!surface.element.isConnected) chat.append(surface.element);
}

function renderComponent(surface, id) {
  const component = surface.components.get(id);
  if (!component) return document.createTextNode(`[missing component: ${id}]`);

  if (component.component === "Column") {
    const element = document.createElement("div");
    element.className = "a2ui-column";
    for (const child of component.children) element.append(renderComponent(surface, child));
    return element;
  }

  if (component.component === "Text") {
    const element = document.createElement("p");
    element.className = `a2ui-text a2ui-${component.variant ?? "body"}`;
    element.textContent = resolve(surface, component.text) ?? "";
    return element;
  }

  if (component.component === "ComparisonTable") {
    const table = document.createElement("table");
    table.innerHTML = "<thead><tr><th>Old value</th><th>New value</th></tr></thead>";
    const row = table.insertRow();
    row.insertCell().textContent = resolve(surface, component.oldValue) ?? "";
    row.insertCell().textContent = resolve(surface, component.newValue) ?? "";
    return table;
  }

  if (component.component === "Button") {
    const button = document.createElement("button");
    button.className = "a2ui-button";
    button.textContent = resolve(surface, component.label);
    button.disabled = Boolean(resolve(surface, component.disabled));
    button.addEventListener("click", () => void dispatchAction(surface, component));
    return button;
  }

  return document.createTextNode(`[unsupported catalog component: ${component.component}]`);
}

async function dispatchAction(surface, component) {
  const event = component.action?.event;
  try {
    const context = Object.fromEntries(
      Object.entries(event.context ?? {}).map(([key, value]) => [key, resolve(surface, value)])
    );
    const result = await callTool("a2ui_action", {
      name: event.name,
      surfaceId: surface.surfaceId,
      sourceComponentId: component.id,
      timestamp: new Date().toISOString(),
      context
    });
    await processToolResult(result);
  } catch (error) {
    addMessage(error.message, "assistant error");
  }
}

function preferredNameFrom(text) {
  const match = text.match(/update\s+(?:my\s+)?preferred\s+name\s+to\s+(.+?)\s*[.!]?$/i);
  return match?.[1]?.trim();
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const text = messageInput.value.trim();
  if (!text) return;
  addMessage(text, "user");
  messageInput.value = "";

  try {
    const preferredName = preferredNameFrom(text);
    if (!preferredName) {
      addMessage("Try: I want to update my preferred name to XYZ.");
      return;
    }
    const result = await callTool("get_preferred_name_confirmation", { preferredName });
    await processToolResult(result);
  } catch (error) {
    addMessage(error.message, "assistant error");
  }
});
